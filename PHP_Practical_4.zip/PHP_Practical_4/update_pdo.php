<?php
$conn=new PDO("mysql:host=localhost;dbname=college","root","");
$conn->exec("UPDATE students SET marks=98 WHERE id=4");
echo "Record Updated";
?>