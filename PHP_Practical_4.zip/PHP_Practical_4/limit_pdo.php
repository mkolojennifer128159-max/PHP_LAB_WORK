<?php
$conn=new PDO("mysql:host=localhost;dbname=college","root","");
$result=$conn->query("SELECT * FROM students LIMIT 3");
foreach($result as $row) echo $row["id"]." ".$row["name"]." ".$row["marks"]."<br>";
?>