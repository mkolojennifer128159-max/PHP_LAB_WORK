<?php
try {
$conn = new PDO("mysql:host=localhost;dbname=college","root","");
$sql="CREATE TABLE students(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(50),course VARCHAR(30),marks INT)";
$conn->exec($sql);
echo "Table Created";
} catch(PDOException $e){ echo "Error"; }
?>