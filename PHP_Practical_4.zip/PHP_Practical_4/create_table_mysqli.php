<?php
$conn = new mysqli("localhost", "root", "", "college");
$sql = "CREATE TABLE students(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(50),course VARCHAR(30),marks INT)";
if ($conn->query($sql)) echo "Table Created"; else echo "Error";
$conn->close();
?>