<?php
$conn=new PDO("mysql:host=localhost;dbname=college","root","");
$result=$conn->query("SELECT * FROM students");
echo "<table border=1><tr><th>ID</th><th>Name</th><th>Course</th><th>Marks</th></tr>";
foreach($result as $row){
echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['course']}</td><td>{$row['marks']}</td></tr>";
}
echo "</table>";
?>