<?php
$conn=new mysqli("localhost","root","","college");
$sql="INSERT INTO students(name,course,marks) VALUES('Jenny','BCA',85)";
if($conn->query($sql)) echo "Data Inserted";
$conn->close();
?>