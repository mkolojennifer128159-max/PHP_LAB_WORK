<?php
$conn=new mysqli("localhost","root","","college");
if($conn->query("DELETE FROM students WHERE id=1")) echo "Record Deleted";
$conn->close();
?>