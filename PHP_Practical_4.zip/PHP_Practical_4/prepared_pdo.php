<?php
$conn=new PDO("mysql:host=localhost;dbname=college","root","");
$stmt=$conn->prepare("INSERT INTO students(name,course,marks) VALUES(?,?,?)");
$stmt->execute(["Priya","BCA",92]);
echo "Record Inserted";
?>