<?php
try{
$conn=new PDO("mysql:host=localhost;dbname=college","root","");
$conn->exec("INSERT INTO students(name,course,marks) VALUES('Huda','BCA',90)");
echo "Data Inserted";
}catch(PDOException $e){ echo "Error"; }
?>