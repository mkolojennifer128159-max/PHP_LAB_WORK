<?php
$conn=new mysqli("localhost","root","","college");
if($conn->query("UPDATE students SET marks=95 WHERE id=3")) echo "Record Updated";
$conn->close();
?>