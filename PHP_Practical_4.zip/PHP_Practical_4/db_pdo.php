<?php
try {
    $conn = new PDO("mysql:host=localhost;dbname=college", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "PDO Connected Successfully";
} catch(PDOException $e) { echo "Connection Failed"; }
?>