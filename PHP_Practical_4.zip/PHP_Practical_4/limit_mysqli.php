<?php
$conn=new mysqli("localhost","root","","college");
$result=$conn->query("SELECT * FROM students LIMIT 3");
while($row=$result->fetch_assoc()) echo $row["id"]." ".$row["name"]." ".$row["marks"]."<br>";
$conn->close();
?>