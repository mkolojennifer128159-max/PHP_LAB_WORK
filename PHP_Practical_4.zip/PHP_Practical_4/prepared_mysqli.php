<?php
$conn=new mysqli("localhost","root","","college");
$stmt=$conn->prepare("INSERT INTO students(name,course,marks) VALUES(?,?,?)");
$name="Rahul"; $course="BCA"; $marks=88;
$stmt->bind_param("ssi",$name,$course,$marks);
$stmt->execute();
echo "Record Inserted";
$stmt->close(); $conn->close();
?>