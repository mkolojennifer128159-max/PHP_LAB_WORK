<?php
$conn=new mysqli("localhost","root","","college");
$result=$conn->query("SELECT * FROM students");
echo "<table border=1><tr><th>ID</th><th>Name</th><th>Course</th><th>Marks</th></tr>";
while($row=$result->fetch_assoc()){
echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['course']}</td><td>{$row['marks']}</td></tr>";
}
echo "</table>";
$conn->close();
?>