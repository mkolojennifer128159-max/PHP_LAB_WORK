<?php
$conn=new PDO("mysql:host=localhost;dbname=college","root","");
$conn->exec("DELETE FROM students WHERE id=2");
echo "Record Deleted";
?>