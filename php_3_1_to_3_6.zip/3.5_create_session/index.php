<?php
session_start();
$_SESSION["username"] = "Luyanda";
?>
<h2>Create Session</h2>
<p>Session created successfully.</p>
<p>Username: <?php echo $_SESSION["username"]; ?></p>
