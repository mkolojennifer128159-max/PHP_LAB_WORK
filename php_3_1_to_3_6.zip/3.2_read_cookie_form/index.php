<?php
if (isset($_COOKIE["username"])) {
    $name = $_COOKIE["username"];
} else {
    $name = "No cookie found";
}
?>
<h2>Read Cookie</h2>
<p>Username stored in cookie: <?php echo $name; ?></p>
