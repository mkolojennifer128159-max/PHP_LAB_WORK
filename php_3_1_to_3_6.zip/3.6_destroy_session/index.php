<?php
session_start();
session_unset();
session_destroy();
?>
<h2>Destroy Session</h2>
<p>Session destroyed successfully.</p>
