<?php
setcookie("username", "", time() - 3600);
?>
<h2>Delete Cookie</h2>
<p>The username cookie has been deleted.</p>
