<?php
if (isset($_COOKIE["username"])) {
    echo "<h2>Welcome, " . $_COOKIE["username"] . "!</h2>";
} else {
    echo "<h2>Cookie not found.</h2>";
}
?>
