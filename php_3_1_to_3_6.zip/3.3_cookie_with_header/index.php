<?php
if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    setcookie("username", $name, time() + 3600);
    header("Location: welcome.php");
    exit();
}
?>
<h2>Cookie with Header</h2>
<form method="POST">
    Enter Name: <input type="text" name="name" required>
    <input type="submit" name="submit" value="Submit">
</form>
