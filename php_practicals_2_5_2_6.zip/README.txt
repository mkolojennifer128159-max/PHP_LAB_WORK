PHP Practicals 2.5 and 2.6

2.5 uses settype() and gettype() for type casting.
2.6 uses a user-defined calculator() function and a simple HTML form.

No MySQL database is required.

Run with XAMPP:
http://localhost/2.5_type_casting/
http://localhost/2.6_calculator/
