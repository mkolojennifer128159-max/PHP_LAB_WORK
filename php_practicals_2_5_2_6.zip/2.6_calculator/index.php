<?php
function calculator($num1, $num2, $operator)
{
    switch ($operator) {
        case "+":
            return $num1 + $num2;
        case "-":
            return $num1 - $num2;
        case "*":
            return $num1 * $num2;
        case "/":
            if ($num2 == 0) {
                return "Cannot divide by zero";
            }
            return $num1 / $num2;
        default:
            return "Invalid operator";
    }
}

$result = "";

if (isset($_POST["calculate"])) {
    $num1 = $_POST["num1"];
    $num2 = $_POST["num2"];
    $operator = $_POST["operator"];

    $result = calculator($num1, $num2, $operator);
}
?>

<h2>Simple Calculator</h2>

<form method="POST">
    Enter First Number:
    <input type="number" name="num1" required><br><br>

    Enter Second Number:
    <input type="number" name="num2" required><br><br>

    Select Operator:
    <select name="operator">
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>
    </select><br><br>

    <input type="submit" name="calculate" value="Calculate">
</form>

<?php
if ($result !== "") {
    echo "<h3>Result: $result</h3>";
}
?>