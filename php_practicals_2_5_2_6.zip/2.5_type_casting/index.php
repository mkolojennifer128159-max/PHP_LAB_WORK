<?php
$value = "25";

echo "<h2>Type Casting in PHP</h2>";
echo "Original value: $value<br>";
echo "Original type: " . gettype($value) . "<br><br>";

settype($value, "integer");

echo "After settype(): $value<br>";
echo "New type: " . gettype($value) . "<br>";
?>