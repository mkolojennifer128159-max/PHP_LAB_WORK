<?php
$conn = new mysqli("localhost", "root", "", "php_practicals");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$limit = isset($_GET["limit"]) ? (int)$_GET["limit"] : 3;
if ($limit < 1) $limit = 3;
$result = $conn->query("SELECT * FROM students ORDER BY id LIMIT $limit");
?>
<!DOCTYPE html>
<html><head><title>4.8 LIMIT MySQLi</title></head><body>
<h1>4.8 Limit Data Selections Using MySQLi</h1>
<form method="get">Number of records: <input type="number" name="limit" min="1" value="<?= $limit ?>"><button type="submit">Show</button></form>
<table border="1" cellpadding="8" cellspacing="0"><tr><th>ID</th><th>Name</th><th>Course</th><th>Marks</th></tr>
<?php while ($row = $result->fetch_assoc()): ?><tr><td><?= $row['id'] ?></td><td><?= htmlspecialchars($row['name']) ?></td><td><?= htmlspecialchars($row['course']) ?></td><td><?= $row['marks'] ?></td></tr><?php endwhile; ?>
</table></body></html>
<?php $conn->close(); ?>
