<?php
$conn = new mysqli("localhost", "root", "", "php_practicals");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = (int)$_POST["id"];
    $name = $_POST["name"];
    $course = $_POST["course"];
    $marks = (int)$_POST["marks"];
    $stmt = $conn->prepare("UPDATE students SET name=?, course=?, marks=? WHERE id=?");
    $stmt->bind_param("ssii", $name, $course, $marks, $id);
    $message = $stmt->execute() ? "Data updated successfully using MySQLi." : "Error updating data.";
    $stmt->close();
}
$result = $conn->query("SELECT * FROM students ORDER BY id");
?>
<!DOCTYPE html>
<html><head><title>4.7 MySQLi Update</title></head><body>
<h1>4.7 Update Data Using MySQLi</h1>
<p><?= htmlspecialchars($message) ?></p>
<form method="post">
ID<br><input type="number" name="id" required><br><br>
Name<br><input type="text" name="name" required><br><br>
Course<br><input type="text" name="course" required><br><br>
Marks<br><input type="number" name="marks" required><br><br>
<button type="submit">Update</button>
</form>
<table border="1" cellpadding="8" cellspacing="0"><tr><th>ID</th><th>Name</th><th>Course</th><th>Marks</th></tr>
<?php while ($row = $result->fetch_assoc()): ?><tr><td><?= $row['id'] ?></td><td><?= htmlspecialchars($row['name']) ?></td><td><?= htmlspecialchars($row['course']) ?></td><td><?= $row['marks'] ?></td></tr><?php endwhile; ?>
</table></body></html>
<?php $conn->close(); ?>
