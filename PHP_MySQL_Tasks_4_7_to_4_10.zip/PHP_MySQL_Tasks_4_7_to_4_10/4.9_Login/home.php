<?php
session_start();
if (!isset($_SESSION["user_id"])) { header("Location: auth.php"); exit; }
?>
<!DOCTYPE html>
<html><head><title>Home</title></head><body>
<h1>Welcome <?= htmlspecialchars($_SESSION["full_name"]) ?></h1>
<p>Username: <?= htmlspecialchars($_SESSION["username"]) ?></p>
<p>Email: <?= htmlspecialchars($_SESSION["email"]) ?></p>
<p>Phone: <?= htmlspecialchars($_SESSION["phone"]) ?></p>
<a href="../4.10_Edit_Profile/edit_profile.php">Edit Profile</a> |
<a href="logout.php">Logout</a>
</body></html>
