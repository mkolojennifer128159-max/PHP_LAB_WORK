<?php
session_start();
$conn = new mysqli("localhost", "root", "", "php_practicals");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];
    $stmt = $conn->prepare("SELECT id, username, password, full_name, email, phone FROM users WHERE username=? AND password=?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["full_name"] = $user["full_name"];
        $_SESSION["email"] = $user["email"];
        $_SESSION["phone"] = $user["phone"];
        header("Location: home.php");
        exit;
    }
    $error = "Invalid username or password.";
    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html><head><title>4.9 Login</title></head><body>
<h1>4.9 User Login</h1>
<p style="color:red"><?= htmlspecialchars($error) ?></p>
<form method="post">
Username<br><input type="text" name="username" required><br><br>
Password<br><input type="password" name="password" required><br><br>
<button type="submit">Login</button>
</form>
<p>Test login: admin / admin123</p>
</body></html>
