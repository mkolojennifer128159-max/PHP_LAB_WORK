CREATE DATABASE IF NOT EXISTS php_practicals;
USE php_practicals;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL
);

INSERT INTO users (username, password, full_name, email, phone)
VALUES ('admin', 'admin123', 'Admin User', 'admin@example.com', '9876543210')
ON DUPLICATE KEY UPDATE username = username;

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL,
    marks INT NOT NULL
);

INSERT INTO students (name, course, marks) VALUES
('John', 'BCA', 85),
('Mary', 'BCA', 78),
('David', 'BCA', 92),
('Sarah', 'BCA', 74),
('Peter', 'BCA', 88);
