PHP MySQL Tasks 4.7 to 4.10

Requirements:
- XAMPP with Apache and MySQL
- PHP 7 or newer
- phpMyAdmin

Setup:
1. Copy the PHP_MySQL_Tasks_4_7_to_4_10 folder into C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP.
3. Open http://localhost/phpmyadmin/
4. Import database.sql.
5. Open the task folders through localhost.

Database: php_practicals
MySQL user: root
MySQL password: empty by default in XAMPP

Default login:
Username: admin
Password: admin123
