<?php
session_start();
if (!isset($_SESSION["user_id"])) { header("Location: ../4.9_Login/auth.php"); exit; }
$conn = new mysqli("localhost", "root", "", "php_practicals");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$message = "";
$user_id = (int)$_SESSION["user_id"];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST["full_name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $stmt = $conn->prepare("UPDATE users SET full_name=?, email=?, phone=? WHERE id=?");
    $stmt->bind_param("sssi", $full_name, $email, $phone, $user_id);
    if ($stmt->execute()) {
        $_SESSION["full_name"] = $full_name;
        $_SESSION["email"] = $email;
        $_SESSION["phone"] = $phone;
        $message = "Profile updated successfully.";
    } else { $message = "Unable to update profile."; }
    $stmt->close();
}
$stmt = $conn->prepare("SELECT username, full_name, email, phone FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows !== 1) die("User not found.");
$user = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html><head><title>4.10 Edit Profile</title></head><body>
<h1>4.10 Edit Profile</h1>
<p style="color:green"><?= htmlspecialchars($message) ?></p>
<form method="post">
Username<br><input type="text" value="<?= htmlspecialchars($user['username']) ?>" readonly><br><br>
Full Name<br><input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required><br><br>
Email<br><input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>
Phone<br><input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required><br><br>
<button type="submit">Save Changes</button>
</form>
<p><a href="../4.9_Login/home.php">Back to Home</a></p>
</body></html>
