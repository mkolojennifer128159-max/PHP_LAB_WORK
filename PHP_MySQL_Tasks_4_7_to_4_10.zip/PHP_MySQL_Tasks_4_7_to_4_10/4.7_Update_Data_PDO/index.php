<?php
try {
    $conn = new PDO("mysql:host=localhost;dbname=php_practicals", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Connection failed: " . $e->getMessage()); }
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = (int)$_POST["id"];
    $name = $_POST["name"];
    $course = $_POST["course"];
    $marks = (int)$_POST["marks"];
    $stmt = $conn->prepare("UPDATE students SET name=?, course=?, marks=? WHERE id=?");
    $message = $stmt->execute([$name, $course, $marks, $id]) ? "Data updated successfully using PDO." : "Error updating data.";
}
$result = $conn->query("SELECT * FROM students ORDER BY id");
?>
<!DOCTYPE html>
<html><head><title>4.7 PDO Update</title></head><body>
<h1>4.7 Update Data Using PDO</h1>
<p><?= htmlspecialchars($message) ?></p>
<form method="post">
ID<br><input type="number" name="id" required><br><br>
Name<br><input type="text" name="name" required><br><br>
Course<br><input type="text" name="course" required><br><br>
Marks<br><input type="number" name="marks" required><br><br>
<button type="submit">Update</button>
</form>
<table border="1" cellpadding="8" cellspacing="0"><tr><th>ID</th><th>Name</th><th>Course</th><th>Marks</th></tr>
<?php while ($row = $result->fetch(PDO::FETCH_ASSOC)): ?><tr><td><?= $row['id'] ?></td><td><?= htmlspecialchars($row['name']) ?></td><td><?= htmlspecialchars($row['course']) ?></td><td><?= $row['marks'] ?></td></tr><?php endwhile; ?>
</table></body></html>
