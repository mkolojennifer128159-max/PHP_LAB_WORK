<?php
try {
    $conn = new PDO("mysql:host=localhost;dbname=php_practicals", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Connection failed: " . $e->getMessage()); }
$limit = isset($_GET["limit"]) ? (int)$_GET["limit"] : 3;
if ($limit < 1) $limit = 3;
$stmt = $conn->prepare("SELECT * FROM students ORDER BY id LIMIT " . $limit);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html><head><title>4.8 LIMIT PDO</title></head><body>
<h1>4.8 Limit Data Selections Using PDO</h1>
<form method="get">Number of records: <input type="number" name="limit" min="1" value="<?= $limit ?>"><button type="submit">Show</button></form>
<table border="1" cellpadding="8" cellspacing="0"><tr><th>ID</th><th>Name</th><th>Course</th><th>Marks</th></tr>
<?php foreach ($rows as $row): ?><tr><td><?= $row['id'] ?></td><td><?= htmlspecialchars($row['name']) ?></td><td><?= htmlspecialchars($row['course']) ?></td><td><?= $row['marks'] ?></td></tr><?php endforeach; ?>
</table></body></html>
