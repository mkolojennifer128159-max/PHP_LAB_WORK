<?php
$conn = mysqli_connect("localhost", "root", "", "date_db", 3306);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$dateTime = date("Y-m-d H:i:s");

$sql = "SELECT
        HOUR('$dateTime') AS hour_value,
        MINUTE('$dateTime') AS minute_value,
        SECOND('$dateTime') AS second_value,
        DATE_FORMAT('$dateTime', '%d-%m-%Y %H:%i:%s') AS formatted_date,
        DATE_SUB('$dateTime', INTERVAL 7 DAY) AS previous_date";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<h2>MySQL Date and Time Functions</h2>

<p>Current Date and Time: <?php echo $dateTime; ?></p>
<p>HOUR(): <?php echo $row["hour_value"]; ?></p>
<p>MINUTE(): <?php echo $row["minute_value"]; ?></p>
<p>SECOND(): <?php echo $row["second_value"]; ?></p>
<p>DATE_FORMAT(): <?php echo $row["formatted_date"]; ?></p>
<p>DATE_SUB() - 7 Days: <?php echo $row["previous_date"]; ?></p>
