<?php
$conn = mysqli_connect("localhost", "root", "", "date_db", 3306);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT
        CURDATE() AS current_date1,
        CURRENT_DATE AS current_date2,
        CURTIME() AS current_time1,
        CURRENT_TIME() AS current_time2,
        UNIX_TIMESTAMP() AS unix_time,
        FROM_UNIXTIME(UNIX_TIMESTAMP()) AS normal_time";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<h2>MySQL Date and Time Functions</h2>

<p>CURDATE(): <?php echo $row["current_date1"]; ?></p>
<p>CURRENT_DATE: <?php echo $row["current_date2"]; ?></p>
<p>CURTIME(): <?php echo $row["current_time1"]; ?></p>
<p>CURRENT_TIME(): <?php echo $row["current_time2"]; ?></p>
<p>UNIX_TIMESTAMP(): <?php echo $row["unix_time"]; ?></p>
<p>FROM_UNIXTIME(): <?php echo $row["normal_time"]; ?></p>
