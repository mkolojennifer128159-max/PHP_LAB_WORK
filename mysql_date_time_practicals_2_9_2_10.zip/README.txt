MySQL Date and Time Functions - Practicals 2.9 and 2.10

1. Start Apache and MySQL in XAMPP.
2. Open phpMyAdmin.
3. Run database.sql to create the date_db database.
4. Put the two folders inside C:\xampp\htdocs\

Run:
http://localhost/2.9_mysql_date_time_functions/
http://localhost/2.10_mysql_date_time_functions/

MySQL functions demonstrated:
2.9: HOUR(), MINUTE(), SECOND(), DATE_FORMAT(), DATE_SUB()
2.10: CURDATE(), CURRENT_DATE, CURTIME(), CURRENT_TIME(), UNIX_TIMESTAMP(), FROM_UNIXTIME()
