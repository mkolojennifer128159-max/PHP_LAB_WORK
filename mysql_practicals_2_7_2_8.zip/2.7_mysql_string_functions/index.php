<?php
$conn = mysqli_connect("localhost", "root", "", "string_db", 3306);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$text = "  Hello PHP  ";

$sql = "SELECT
        LENGTH('$text') AS length_value,
        CONCAT('Hello', ' ', 'World') AS concat_value,
        CONCAT_WS('-', '2026', '09', '04') AS concat_ws_value,
        TRIM('$text') AS trim_value,
        RTRIM('$text') AS rtrim_value,
        LTRIM('$text') AS ltrim_value,
        LPAD('PHP', 8, '*') AS lpad_value,
        RPAD('PHP', 8, '*') AS rpad_value,
        LOCATE('PHP', '$text') AS locate_value";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<h2>MySQL String Manipulation Functions</h2>
<p>LENGTH(): <?php echo $row["length_value"]; ?></p>
<p>CONCAT(): <?php echo $row["concat_value"]; ?></p>
<p>CONCAT_WS(): <?php echo $row["concat_ws_value"]; ?></p>
<p>TRIM(): <?php echo $row["trim_value"]; ?></p>
<p>RTRIM(): <?php echo $row["rtrim_value"]; ?></p>
<p>LTRIM(): <?php echo $row["ltrim_value"]; ?></p>
<p>LPAD(): <?php echo $row["lpad_value"]; ?></p>
<p>RPAD(): <?php echo $row["rpad_value"]; ?></p>
<p>LOCATE(): <?php echo $row["locate_value"]; ?></p>
