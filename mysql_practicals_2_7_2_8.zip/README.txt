PHP/MySQL Practicals 2.7 and 2.8

2.7:
LENGTH(), CONCAT(), CONCAT_WS(), TRIM(), RTRIM(), LTRIM(),
LPAD(), RPAD(), LOCATE()

2.8:
DAYOFWEEK(), WEEKDAY(), DAYOFMONTH(), DAYOFYEAR(), DAYNAME()

Setup:
1. Start Apache and MySQL in XAMPP.
2. Open phpMyAdmin.
3. Run database.sql.
4. Put the folders inside C:\xampp\htdocs\

Run:
http://localhost/2.7_mysql_string_functions/
http://localhost/2.8_mysql_date_time_functions/
