<?php
$conn = mysqli_connect("localhost", "root", "", "date_db", 3306);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT
        DAYOFWEEK(CURDATE()) AS dayofweek_value,
        WEEKDAY(CURDATE()) AS weekday_value,
        DAYOFMONTH(CURDATE()) AS dayofmonth_value,
        DAYOFYEAR(CURDATE()) AS dayofyear_value,
        DAYNAME(CURDATE()) AS dayname_value";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<h2>MySQL Date and Time Functions</h2>
<p>Current Date: <?php echo date("Y-m-d"); ?></p>
<p>DAYOFWEEK(): <?php echo $row["dayofweek_value"]; ?></p>
<p>WEEKDAY(): <?php echo $row["weekday_value"]; ?></p>
<p>DAYOFMONTH(): <?php echo $row["dayofmonth_value"]; ?></p>
<p>DAYOFYEAR(): <?php echo $row["dayofyear_value"]; ?></p>
<p>DAYNAME(): <?php echo $row["dayname_value"]; ?></p>
