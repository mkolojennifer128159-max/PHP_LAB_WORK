<?php
$names = ["Jennifer", "John", "James", "Jenny", "Jessica", "Daniel", "David", "Michael"];
$q = strtolower(trim($_GET["q"] ?? ""));
if ($q === "") {
    echo "Start typing to search.";
    exit;
}
$matches = [];
foreach ($names as $name) {
    if (stripos($name, $q) !== false) {
        $matches[] = $name;
    }
}
echo count($matches) ? implode("<br>", $matches) : "No results found.";
?>