<!DOCTYPE html>
<html>
<head><title>5.4 Live Search</title></head>
<body>
<h2>Live Search Using AJAX</h2>
<input type="text" id="search" onkeyup="searchData()" placeholder="Type a name">
<div id="result"></div>
<script>
function searchData() {
    var value = document.getElementById("search").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("result").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", "search.php?q=" + encodeURIComponent(value), true);
    xhttp.send();
}
</script>
</body>
</html>