CREATE DATABASE ajax_demo;
USE ajax_demo;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    course VARCHAR(100),
    semester INT
);

INSERT INTO students (name, course, semester) VALUES
('Jennifer', 'BCA', 3),
('John', 'BCA', 3),
('Jessica', 'BCA', 4);