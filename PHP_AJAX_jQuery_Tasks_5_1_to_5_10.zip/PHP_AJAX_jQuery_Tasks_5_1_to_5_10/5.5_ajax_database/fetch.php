<?php
include "config.php";
$result = $conn->query("SELECT * FROM students");
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>ID</th><th>Name</th><th>Course</th><th>Semester</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
    echo "<td>" . htmlspecialchars($row["name"]) . "</td>";
    echo "<td>" . htmlspecialchars($row["course"]) . "</td>";
    echo "<td>" . htmlspecialchars($row["semester"]) . "</td>";
    echo "</tr>";
}
echo "</table>";
$conn->close();
?>