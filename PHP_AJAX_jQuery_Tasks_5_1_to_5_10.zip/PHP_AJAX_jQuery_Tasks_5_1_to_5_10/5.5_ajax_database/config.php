<?php
$conn = new mysqli("localhost", "root", "", "ajax_demo");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>