<!DOCTYPE html>
<html>
<head><title>5.5 AJAX Database</title></head>
<body>
<h2>Fetch Data from Database with AJAX</h2>
<button onclick="loadStudents()">Load Students</button>
<div id="output"></div>
<script>
function loadStudents() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("output").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", "fetch.php", true);
    xhttp.send();
}
</script>
</body>
</html>