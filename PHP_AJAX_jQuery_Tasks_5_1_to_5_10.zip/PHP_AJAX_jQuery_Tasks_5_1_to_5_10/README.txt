PHP AJAX & jQuery Practical Tasks 5.1 to 5.10

Requirements:
- XAMPP/WAMP/Laragon for PHP tasks 5.4, 5.5, 5.9 and 5.10.
- A web browser.
- Internet connection for jQuery CDN tasks 5.6 to 5.10.

How to run:
1. Extract this ZIP into your XAMPP htdocs folder.
2. Start Apache in XAMPP.
3. For task 5.5, start MySQL and import 5.5_ajax_database/db.sql in phpMyAdmin.
4. Open:
   http://localhost/PHP_AJAX_jQuery_Tasks_5_1_to_5_10/5.4_live_search/
   and similarly for tasks 5.5, 5.9 and 5.10.
5. Tasks 5.1, 5.2, 5.3, 5.6, 5.7 and 5.8 can also be opened directly in a browser, although using a local server is recommended for XMLHttpRequest behavior.

Task list:
5.1 Simple XMLHttpRequest and TXT file
5.2 XMLHttpRequest with callback and TXT file
5.3 Retrieve all header information
5.4 AJAX communication while typing
5.5 AJAX database retrieval
5.6 Check whether jQuery is loaded
5.7 Smooth scroll to top with jQuery
5.8 jQuery selectors and red background
5.9 AJAX search suggestions with jQuery
5.10 AJAX navigation with dynamically loaded content
