<!DOCTYPE html>
<html>
<head>
<title>5.9 Search Suggestions</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>
<h2>Search Suggestions</h2>
<input type="text" id="search" placeholder="Type to search">
<div id="suggestions"></div>
<script>
$("#search").on("keyup", function() {
    var query = $(this).val();
    if (query.length === 0) {
        $("#suggestions").html("");
        return;
    }
    $.ajax({
        url: "suggestions.php",
        type: "GET",
        data: {q: query},
        success: function(data) {
            $("#suggestions").html(data);
        }
    });
});
</script>
</body>
</html>