<?php
$items = ["Apple", "Apricot", "Banana", "Blueberry", "Cherry", "Grapes", "Mango", "Orange", "Pineapple", "Strawberry"];
$q = strtolower(trim($_GET["q"] ?? ""));
$results = [];
foreach ($items as $item) {
    if ($q !== "" && stripos($item, $q) !== false) {
        $results[] = $item;
    }
}
echo count($results) ? implode("<br>", $results) : "No suggestions found.";
?>